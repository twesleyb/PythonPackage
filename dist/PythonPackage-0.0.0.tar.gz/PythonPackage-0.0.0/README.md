# PythonPackage

An example python package.

The EVcouplings package was used as an example.

## The Python Environment

Always try to work in a python virtual environment. I find that `conda` works
well for me. 
* Create a new environment
* Install pip
* Install requirments.txt

## Installation
