"""
Short Description

Authors:
  Author 1
  Author 2
"""

def my_fun():
    """
    function description
    """
    return "hello world"
